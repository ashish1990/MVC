﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;
using Administrator.Models;


namespace Administrator.Controllers
{
    public class HomeController : Controller
    {
        // 
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(object sender, EventArgs e)
        {
            
            string constr = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (MySqlConnection con = new MySqlConnection(constr))
            {
                string user = Request["username"];
                string pass = Request["pass"];

                string query = "SELECT user_id, user_email FROM gmrx_users WHERE user_id='"+user+"' AND user_password='"+pass+"' Limit 1";
                using (MySqlCommand cmd = new MySqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    using (MySqlDataReader sdr = cmd.ExecuteReader())
                    {
                        sdr.Read();
                        Session["gmrx_user_id"] = sdr["user_id"];
                        Session["gmrx_user_email"] = sdr["user_email"]; 
                    }
                    con.Close();
                    if (Session["gmrx_user_id"] != null && Session["gmrx_user_email"] != null)
                    {
                        return RedirectToAction("index", "dashboard");
                    }
                    else
                    {
                        return RedirectToAction("index", "home");
                    }
                }
                
       
            }

        }

    }
}

