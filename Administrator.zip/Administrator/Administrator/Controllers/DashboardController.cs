﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;
using Administrator.Models;


namespace Administrator.Controllers
{
    public class DashboardController : Controller
    {
        //
        // GET: /Dashboard/

        public ActionResult Index()
        {
            List<Login> users = new List<Login>();
            string constr = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
            using (MySqlConnection con = new MySqlConnection(constr))
            {
                string query = "SELECT user_firstname,user_lastname,user_phone,user_dob,user_gender,user_country,user_type FROM gmrx_users Where user_id = '" + Session["gmrx_user_id"] + "' Limit 1";
                using (MySqlCommand cmd = new MySqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    using (MySqlDataReader sdr = cmd.ExecuteReader())
                    {
                        while (sdr.Read())
                        {
                            users.Add(new Login
                            {
                                user_firstname = sdr["user_firstname"].ToString(),
                                user_lastname = sdr["user_lastname"].ToString(),
                                user_phone = sdr["user_phone"].ToString(),
                                user_dob = sdr["user_dob"].ToString(),
                                user_gender = Convert.ToInt32(sdr["user_gender"]),
                                user_country = sdr["user_country"].ToString(),
                                user_type = Convert.ToInt32(sdr["user_type"])
                            });
                        }
                    }
                    con.Close();
                }
            }

            return View(users);
        }

    }
}
