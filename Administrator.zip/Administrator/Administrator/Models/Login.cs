﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Administrator.Models
{
    public class Login
    {
        public string user_firstname { get; set; }
        public string user_lastname { get; set; }
        public string user_phone { get; set; }
        public string user_dob { get; set; }
        public int user_gender { get; set; }
        public string user_country { get; set; }
        public int user_type { get; set; }
    }
}